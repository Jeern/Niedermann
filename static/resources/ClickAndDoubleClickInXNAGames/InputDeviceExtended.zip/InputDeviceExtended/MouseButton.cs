﻿//(c) Jesper Niedermann 2010
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PTC.Input
{
    public enum MouseButton
    {
        Left,
        Middle,
        Right,
        XButton1,
        XButton2
    }
}
