﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqPerfTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start");
            DateTime time = DateTime.Now;
            TestForeach();
            Console.WriteLine("ForEach Time: {0}", (DateTime.Now-time).TotalSeconds.ToString());
            Console.ReadLine();
            time = DateTime.Now;
            TestExecute();
            Console.WriteLine("Execute Time: {0}", (DateTime.Now - time).TotalSeconds.ToString());
            Console.WriteLine("Slut");
            Console.ReadLine();
        }

        private static void TestForeach()
        {
            var linqPerf = new LinqPerf();
            (from i in linqPerf.IntList() 
             select i).ToList().ForEach(i => Console.WriteLine(i.ToString()));        
        }

        private static void TestExecute()
        {
            var linqPerf = new LinqPerf();
            (from i in linqPerf.IntList()
             select i).Execute(i => Console.WriteLine(i.ToString()));
        }
    }
}
