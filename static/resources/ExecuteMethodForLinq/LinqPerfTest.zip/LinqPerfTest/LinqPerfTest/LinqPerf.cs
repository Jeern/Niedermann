﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqPerfTest
{
    public class LinqPerf
    {
        private int m_Counter = 0;

        public IEnumerable<int> IntList()
        {
            while (m_Counter <= 100000)
            {
                yield return m_Counter++;
            }
            
        }
    }
}
