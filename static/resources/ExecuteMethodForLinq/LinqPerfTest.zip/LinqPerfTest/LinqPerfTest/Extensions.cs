﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqPerfTest
{
    public static class Extensions
    {
        public static void Execute<T>(this IEnumerable<T> list, Action<T> action) 
        { 
            foreach (T element in list) 
            { 
                action(element); 
            } 
        }
    }
}
